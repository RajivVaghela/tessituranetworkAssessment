﻿using ServiceRegistry.DomainModels;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceRegistry.Data
{
    public interface IStorageClient
    {
        Task<IReadOnlyList<Registration>> ReadDataAsync();

        Task WriteDataAsync(IReadOnlyList<Registration> data);
    }
}