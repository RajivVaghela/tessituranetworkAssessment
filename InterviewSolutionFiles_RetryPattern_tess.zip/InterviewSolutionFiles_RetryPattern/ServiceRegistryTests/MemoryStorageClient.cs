﻿using ServiceRegistry.Data;
using ServiceRegistry.DomainModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceRegistryTests
{
    public class MemoryStorageClient : IStorageClient
    {
        private IReadOnlyList<Registration> _registrations;

        public MemoryStorageClient()
        {
            _registrations = new List<Registration>();
        }

        public MemoryStorageClient(IEnumerable<Registration> registrations)
        {
            _registrations = registrations.ToList();
        }

        public Task<IReadOnlyList<Registration>> ReadDataAsync()
        {
            return Task.FromResult(_registrations);
        }

        public Task WriteDataAsync(IReadOnlyList<Registration> data)
        {
            _registrations = data;

            return Task.CompletedTask;
        }
    }
}