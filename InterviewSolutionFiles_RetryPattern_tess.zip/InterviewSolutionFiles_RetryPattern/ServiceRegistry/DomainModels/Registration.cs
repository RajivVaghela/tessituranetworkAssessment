﻿namespace ServiceRegistry.DomainModels
{
    public class Registration
    {
        public string? ServiceName { get; set; }

        public string? Version { get; set; }

        public string? Domain { get; set; }

        public string? IPAddress { get; set; }
    }
}