﻿using ServiceRegistry.DomainModels;
using System.Threading.Tasks;

namespace ServiceRegistry.Data
{
    public interface IRegistrationsRepository
    {
        Task<Registration> CreateAsync(Registration registration);

        Task<Registration?> GetAsync(string serviceName);
        
        Task<Registration?> GetByVersionAsync(string serviceName, string version);
    }
}