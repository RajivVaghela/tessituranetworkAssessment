using Microsoft.VisualStudio.TestTools.UnitTesting;
using ServiceRegistry.Data;
using ServiceRegistry.DomainModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceRegistryTests
{
    [TestClass]
    public class RegistrationsRepositoryTests
    {
        [TestMethod]
        public async Task CreateItemTest()
        {
            var storage = new MemoryStorageClient();

            var sut = new RegistrationsRepository(storage);

            var item = new Registration { ServiceName = "Sample", Version = "1.0", Domain = "https://sample.com/v1" };

            await sut.CreateAsync(item);

            var actual = await storage.ReadDataAsync();

            Assert.AreEqual(1, actual.Count);

            Assert.AreEqual(item.Version, actual[0].Version);
            Assert.AreEqual(item.ServiceName, actual[0].ServiceName);
            Assert.AreEqual(item.Domain, actual[0].Domain);
            Assert.AreEqual(null, actual[0].IPAddress);
        }

        [TestMethod]
        public async Task ReadItemTest()
        {
            var data = new List<Registration>();

            var item = new Registration { ServiceName = "Sample", Version = "1.0", Domain = "https://sample.com/v1" };

            data.Add(item);

            var storage = new MemoryStorageClient(data);

            var sut = new RegistrationsRepository(storage);

            var actual = await sut.GetByVersionAsync("Sample", "1.0");

            Assert.AreEqual(item.Version, actual.Version);
            Assert.AreEqual(item.ServiceName, actual.ServiceName);
            Assert.AreEqual(item.Domain, actual.Domain);
            Assert.AreEqual(item.IPAddress, actual.IPAddress);
        }
    }
}