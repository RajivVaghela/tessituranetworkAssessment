﻿using Microsoft.AspNetCore.Mvc;
using ServiceRegistry.Data;
using ServiceRegistry.DomainModels;
using System.Threading.Tasks;

namespace ServiceRegistry.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServicesController : ControllerBase
    {
        private readonly IRegistrationsRepository _repository;

        public ServicesController(IRegistrationsRepository repository)
        {
            _repository = repository;
        }

        // GET: Services/{serviceName}?version={version}
        [HttpGet("{serviceName}")]
        public async Task<Registration> GetAsync(string serviceName, string version)
        {
            return await _repository.GetByVersionAsync(serviceName, version);
        }

        // POST: Services/
        [HttpPost]
        public async Task<Registration> PostAsync(Registration item)
        {
            return await _repository.CreateAsync(item);
        }
    }
}