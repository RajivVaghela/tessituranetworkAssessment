﻿using ServiceRegistry.DomainModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceRegistry.Data
{
    /// <summary>
    /// This class simulates network storage
    /// </summary>
    public class FileStorageClient : IStorageClient
    {
        private readonly string _location;

        private readonly Random _randomNetworkLatencySimulator;

        public FileStorageClient(string location)
        {
            _location = location;
            _randomNetworkLatencySimulator = new Random();
        }

        public async Task<IReadOnlyList<Registration>> ReadDataAsync()
        {
            await Task.Delay(_randomNetworkLatencySimulator.Next(2000));

            var json = await File.ReadAllTextAsync(_location);

            var data = System.Text.Json.JsonSerializer.Deserialize(json, typeof(List<Registration>)) as List<Registration>;

            if (data == null)
            {
                throw new Exception("The file data failed to deserialize.");
            }

            return data;
        }

        public async Task WriteDataAsync(IReadOnlyList<Registration> data)
        {

            var json = System.Text.Json.JsonSerializer.Serialize(data);

            await File.WriteAllTextAsync(_location, json);
        }
    }
}