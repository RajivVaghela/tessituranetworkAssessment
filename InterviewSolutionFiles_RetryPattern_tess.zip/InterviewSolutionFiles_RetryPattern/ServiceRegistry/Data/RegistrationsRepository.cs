﻿using ServiceRegistry.DomainModels;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace ServiceRegistry.Data
{
    public class RegistrationsRepository : IRegistrationsRepository
    {
        private readonly IStorageClient _dataStorage;

        static RegistrationsRepository()
        {
        }

        public RegistrationsRepository(IStorageClient dataStorage)
        {
            _dataStorage = dataStorage;
        }

        public async Task<Registration?> GetAsync(string serviceName)
        {
            var data = await _dataStorage.ReadDataAsync();

            var item = data
                .FirstOrDefault(r => string.Equals(r.ServiceName, serviceName, StringComparison.OrdinalIgnoreCase));

            return item;
        }

        public async Task<Registration?> GetByVersionAsync(string serviceName, string version)
        {
            var data = await _dataStorage.ReadDataAsync();

            var item = data
                .Where(r => string.Equals(r.ServiceName, serviceName, StringComparison.OrdinalIgnoreCase))
                .FirstOrDefault(r => string.Equals(r.Version, version, StringComparison.OrdinalIgnoreCase));

            return item;
        }

        public async Task<Registration> CreateAsync(Registration registration)
        {
            await SaveNewItemAsync(registration);

            return registration;
        }

        private async Task SaveNewItemAsync(Registration newItem)
        {
            var readOnlyData = await _dataStorage.ReadDataAsync();

            var data = readOnlyData.ToList();

            data.Add(newItem);

            await _dataStorage.WriteDataAsync(data);
        }
    }
}